export const environment = {
  production: true,
  apiUrl: 'http://18.220.250.200:4000/'
};
